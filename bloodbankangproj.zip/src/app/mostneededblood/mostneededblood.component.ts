import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mostneededblood',
  templateUrl: './mostneededblood.component.html',
  styleUrls: ['./mostneededblood.component.css']
})
export class MostneededbloodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
