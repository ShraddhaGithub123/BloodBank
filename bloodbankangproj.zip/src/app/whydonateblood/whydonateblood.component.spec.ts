import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhydonatebloodComponent } from './whydonateblood.component';

describe('WhydonatebloodComponent', () => {
  let component: WhydonatebloodComponent;
  let fixture: ComponentFixture<WhydonatebloodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhydonatebloodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhydonatebloodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
