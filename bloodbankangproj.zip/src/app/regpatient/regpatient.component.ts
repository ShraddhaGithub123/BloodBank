import { Component, OnInit } from '@angular/core';

import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-regpatient',
  templateUrl: './regpatient.component.html',
  styleUrls: ['./regpatient.component.css']
})
  
  
export class RegpatientComponent implements OnInit {
 myUrl2 = "http://localhost:8080/BloodBankws/bbs/patreg";
 username: String;
  password: String;
  name:String;
   email: String;
   bloodgroup: String;
  mobile: String;
  httpdata;
  constructor(private http:Http) { }

  ngOnInit() {
  }

  onSubmit(event){
     let s=this.myUrl2+this.name+"/"+this.username+"/"+this.password+"/"+this.email+"/"+this.bloodgroup+"/"+this.mobile;
//    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
//    return this.httpdata;
    console.log(s);
  }
  displaydata(data) {this.httpdata = data;}
  
}
