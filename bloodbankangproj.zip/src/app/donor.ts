export class donor {

  name: String;
  username: String;
  password: String;
  dob: String;
  gender: String;
  bloodgroup: String;
  weight: String;
  mobile: String;
  address: String;
  email: String;
  state: String;
  city: String;

}