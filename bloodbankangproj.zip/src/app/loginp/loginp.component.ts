import {BbserviceService} from '../bbservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';

import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';


@Component({
  selector: 'app-loginp',
  templateUrl: './loginp.component.html',
  styleUrls: ['./loginp.component.css'],
  providers: [BbserviceService]
})

export class LoginpComponent implements OnInit {
  myUrl4 = "http://localhost:8080/BloodBankws/rest/bbs/plogin";
  username: String;
  password: String;
  datahttp;
  constructor(private iServe: BbserviceService) {}
  onSubmit(form: NgForm) {

    this.iServe.PLogin(this.username, this.password);
  }

  ngOnInit() {
  }

}
