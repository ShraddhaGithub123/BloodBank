import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';
@Injectable()
export class BbserviceService {

  private myUrl = "http://localhost:8080/BloodBankws/rest/bbs/donorreg";
  private myUrl2 = "http://localhost:8080/BloodBankws/rest/bbs/patreg";
  private myUrl3 = "http://localhost:8080/BloodBankws/rest/bbs/dlogin";
  private myUrl4 = "http://localhost:8080/BloodBankws/rest/bbs/plogin";
  private myUrl5 = "http://localhost:8080/BloodBankws/rest/bbs/donorupd";
  private myUrl6 = "http://localhost:8080/BloodBankws/rest/bbs/dsearch";
  private myUrl7 = "http://localhost:8080/BloodBankws/rest/bbs/dbgsearch";
  private myUrl8 = "http://localhost:8080/BloodBankws/rest/bbs/ddelete";

  //patreg/{name}/{username}/{password}/{email}/{bgroup}/{mobile}
  username: String;
  password: String;
  name: String;
  gender: String;
  email: String;
  dob: String;
  bloodgroup: String;
  mobile: String;
  weight: String;
  address: String;
  state: String;
  city: String;
  httpdata;
  constructor(private http: Http, private router: Router) {

  }

  regDonor(name, username, password, email, dob, gender, bgroup, weight, mnumber, address, state, city) {
    let s = this.myUrl + "/" + name + "/" + username + "/" + password + "/" + dob + "/" + gender + "/" + bgroup + "/" + weight + "/" + mnumber + "/" + address + "/" + email + "/" + state + "/" + city;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    this.router.navigateByUrl('/login');
    return this.httpdata;

  }

  setDonor(name1, username1, password1, email1, dob1, gender1, bgroup1, weight1, mnumber1, address1, state1, city1) {
    //{name}/{username}/{password}/{dob}/{gender}/{bgroup}/{weight}/{mobile}/{address}/{email}/{state}/{city}")
    this.name = name1;
    this.username = username1;
    this.password = password1;
    this.dob = dob1;
    this.gender = gender1;
    this.bloodgroup = bgroup1;
    this.weight = weight1;
    this.mobile = mnumber1;
    this.address = address1;
    this.email = email1;
    this.state = state1;
    this.city = city1;
  }

  regPatient(name, username, password, email, bgroup, mobile) {
    let s = this.myUrl2 + "/" + name + "/" + username + "/" + password + "/" + email + "/" + bgroup + "/" + mobile;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    this.router.navigateByUrl('/login');
    return this.httpdata;
  }
  DLogin(username, password) {

    let s = this.myUrl3 + "/" + username + "/" + password;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    //  console.log(this.httpdata); 
    //this.router.navigateByUrl('/afterlogind');
    return this.httpdata;

  }
  PLogin(username, password) {
    let s = this.myUrl4 + "/" + username + "/" + password;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    this.router.navigateByUrl('/afterloginp');
    return this.httpdata;
  }

  updDonor(name, username, password, email, dob, gender, bgroup, weight, mnumber, address, state, city) {
    let s = this.myUrl5 + "/" + name + "/" + username + "/" + password + "/" + dob + "/" + gender + "/" + bgroup + "/" + weight + "/" + mnumber + "/" + address + "/" + email + "/" + state + "/" + city;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }
  dsearch(city) {
    let s = this.myUrl6 + "/" + city;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }
  dbgsearch(bloodgroup) {
    let s = this.myUrl7 + "/" + bloodgroup;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }
  ddelete(username) {
    let s = this.myUrl8 + "/" + username;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    this.router.navigateByUrl('/home');
    return this.httpdata;
  }

  displaydata(data) {this.httpdata = data;}
}



