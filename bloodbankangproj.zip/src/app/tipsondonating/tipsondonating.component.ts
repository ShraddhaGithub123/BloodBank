import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tipsondonating',
  templateUrl: './tipsondonating.component.html',
  styleUrls: ['./tipsondonating.component.css']
})
export class TipsondonatingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
