export class patient {
  name: String;
  username: String;
  password: String;
  bloodgroup: String;
  mobile: String;
  email: String;

}