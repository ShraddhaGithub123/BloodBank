import {BbserviceService} from '../bbservice.service';
import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';

import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [BbserviceService]
})
export class LoginComponent implements OnInit {
  myUrl3 = "http://localhost:8080/BloodBankws/rest/bbs/dlogin";
  myUrl4 = "http://localhost:8080/BloodBankws/rest/bbs/plogin";
  username: String;
  password: String;
  datahttp:any[];
  constructor(private iServe: BbserviceService,  private router: Router) {}

  onSubmit(form: NgForm) {


    this.datahttp=this.iServe.DLogin(this.username, this.password);
    if(this.datahttp!=null){
      if(this.datahttp[0]=="SUCCESS"){
    this.router.navigateByUrl('/afterlogind');
    }
      else{
        console.log(this.datahttp[0]);
      }
  }
  }
 
  ngOnInit() {
  }

}
