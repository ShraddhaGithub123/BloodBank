import { BbserviceService } from '../bbservice.service';
import { Component, OnInit } from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-registerp',
  templateUrl: './registerp.component.html',
  styleUrls: ['./registerp.component.css'],
  providers:[BbserviceService]
  
  
})
export class RegisterpComponent implements OnInit {
myUrl2 = "http://localhost:8080/BloodBankws/rest/bbs/patreg";
  username: String;
  password: String;
  name:String;
   email: String;
  httpdata;
  btest:boolean;
  

   bloodgroup: String;
  mobile: String;
 
  constructor(private iServe:BbserviceService) {}

  onSubmit(form: NgForm) {
    //if (form.valid) {

      //console.log(form.value);
     //  let s=this.myUrl2+"/" +this.name+"/"+this.username+"/"+this.password+"/"+this.email+"/"+this.bloodgroup+"/"+this.mobile;
    //this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
   // console.log(s);
    //return this.httpdata;
    //}
    this.iServe.regPatient(this.name,this.username,this.password,this.email,this.bloodgroup,this.mobile);

    //this.username=this.password=this.bloodgroup=this.email=this.name=this.mobile="";
    this.btest=true;
    
  }
   //displaydata(data) {this.httpdata = data;}
  
  ngOnInit() {
  }

}
