import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {FormsModule} from '@angular/forms';
import { Router } from '@angular/router';
import {Http, Response, HttpModule} from '@angular/http';
import {AppComponent} from './app.component';
import {RegisterpComponent} from './registerp/registerp.component';
import {RegisterdComponent} from './registerd/registerd.component';
import {HomeComponent} from './home/home.component';
import {WhydonatebloodComponent} from './whydonateblood/whydonateblood.component';
import {WhoneedsbloodComponent} from './whoneedsblood/whoneedsblood.component';
import {TipsondonatingComponent} from './tipsondonating/tipsondonating.component';
import {MostneededbloodComponent} from './mostneededblood/mostneededblood.component';
import {ContactusComponent} from './contactus/contactus.component';
import {LoginComponent} from './login/login.component';
import {AfterloginpComponent} from './afterloginp/afterloginp.component';
import {AfterlogindComponent} from './afterlogind/afterlogind.component';
import { BbserviceService } from './bbservice.service';
import { RegpatientComponent } from './regpatient/regpatient.component';
import { LoginpComponent } from './loginp/loginp.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterpComponent,
    RegisterdComponent,
    HomeComponent,
    WhydonatebloodComponent,
    WhoneedsbloodComponent,
    TipsondonatingComponent,
    MostneededbloodComponent,
    ContactusComponent,
    LoginComponent,
    AfterloginpComponent,
    AfterlogindComponent,
    RegpatientComponent,
    LoginpComponent
  ],
  imports: [
    RouterModule.forRoot([
      {
        path: 'home',
        component: HomeComponent
      },
      {
        path: '',
        redirectTo: '/home', pathMatch: 'full'
      },
      {
        path: 'whydonateblood',
        component: WhydonatebloodComponent
      },
      {
        path: 'whoneedsblood',
        component: WhoneedsbloodComponent
      },
      {
        path: 'tipsondonating',
        component: TipsondonatingComponent
      },
      {
        path: 'mostneededblood',
        component: MostneededbloodComponent
      },
      {
        path: 'contactus',
        component: ContactusComponent
      },
      {
        path: 'registerp',
        component: RegisterpComponent
      },
      {
        path: 'registerd',
        component: RegisterdComponent
      },
      {
        path: 'login',
        component: LoginComponent
      },
      {
        path: 'afterloginp',
        component: AfterloginpComponent
      },
      {
        path: 'afterlogind',
        component: AfterlogindComponent
      },
      {
        path: 'loginp',
        component: LoginpComponent
      }
    ]),
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [BbserviceService],
  bootstrap: [AppComponent]
})
export class AppModule {}
