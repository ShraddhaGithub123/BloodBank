import { TestBed, inject } from '@angular/core/testing';

import { BbserviceService } from './bbservice.service';

describe('BbserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BbserviceService]
    });
  });

  it('should be created', inject([BbserviceService], (service: BbserviceService) => {
    expect(service).toBeTruthy();
  }));
});
